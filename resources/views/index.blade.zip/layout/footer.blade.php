 
      <!-- Wrapper End --> 
      <script src="{{ asset('public/js/jquery-3.6.4.min.js') }}"></script> 
      <script src="{{ asset('public/js/jquery-migrate-3.0.0.min.js') }}"></script> 
      <script src="{{ asset('public/js/popper.min.js') }}"></script> 
      <script src="{{ asset('public/js/bootstrap.min.js') }}"></script> 
      <script src="{{ asset('public/js/bootstrap-select.min.js') }}"></script> 
      <script src="{{ asset('public/js/jquery.mmenu.all.js') }}"></script> 
      <script src="{{ asset('public/js/ace-responsive-menu.js') }}"></script> 
      <script src="{{ asset('public/js/jquery-scrolltofixed-min.js') }}"></script> 
      <script src="{{ asset('public/js/wow.min.js') }}"></script> 
      <script src="{{ asset('public/js/owl.js') }}"></script> 
      <script src="{{ asset('public/js/swiper.js') }}"></script> 
      <script src="{{ asset('public/js/parallax.js') }}"></script>
      <script src="{{ asset('public/js/pricing-slider.js') }}"></script>
      <!-- Custom script for all pages --> 
      <script src="{{ asset('public/js/script.js') }}"></script>
   </body>
</html>