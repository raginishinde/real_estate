      <button class="btn btn-dark btn-icon" id="back-to-top">
      <i class="bi bi-caret-up fs-3xl"></i>
      </button>
      <!--end back-to-top-->
      <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
      <!-- JAVASCRIPT -->
      <script src="{{ asset('public/admin/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
      <script src="{{ asset('public/admin/assets/libs/simplebar/simplebar.min.js') }}"></script>
      <script src="{{ asset('public/admin/assets/js/plugins.js') }}"></script>
      <script src="{{ asset('public/admin/assets/libs/list.js/list.min.js') }}"></script>
      <!-- echarts js -->
      <script src="{{ asset('public/admin/assets/libs/echarts/echarts.min.js') }}"></script>
      <!-- apexcharts -->
      <script src="{{ asset('public/admin/assets/libs/apexcharts/apexcharts.min.js') }}"></script>
      <script src="{{ asset('public/admin/assets/js/pages/dashboard-real-estate.init.js') }}"></script>
      <!-- App js -->
      <script src="{{ asset('public/admin/assets/js/app.js') }}"></script>
      <script src="{{ asset('public/admin/assets/js/admin.js') }}"></script>

  